/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>

using namespace std;

int main()
{
    char value;
    char  again;
    start:
    cout<<"------Welcome to our calculator Application--------"<<endl;
    cout<<"_____please flow the instruction______"<<endl;
    cout<<"(1)please press a for addtion"<<endl;
    cout<<"(2)please press s for subtraction"<<endl;
    cout<<"(3)please press m for multiplication"<<endl;
    cout<<"(4)please press d for division"<<endl;
    cout<<"(5)please press O for modulo"<<endl;
    int addition(void);
    int multiplication(void);
    int subtraction(void);
    int division(void);
    int modulo(void);
    cin>>value;
    if(value=='a'|| value=='A')
    {
        int addValue=addition();
        cout<<"additoin is "<<addValue<<endl;
        cout<<"Do you want to use our application again y or n"<<endl;
        addAgain:
        cin>>again;
        if(again=='y'||again=='Y')
        {
            goto start;
        }
        else if(again=='n'||again=='N'){
        cout<<"than you for use my application"<<endl;
        goto addAgain;
    }

    }
    
    
        if(value=='m'|| value=='M')
    {
        int mulValue=multiplication();
        cout<<"multiplication is "<<mulValue<<endl;
        cout<<"Do you want to use our application again y or n"<<endl;
        mulAgain:
        cin>>again;
        if(again=='y'||again=='Y')
        {
            goto start;
        }
        else if(again=='n'||again=='N'){
        cout<<"than you for use my application"<<endl;
        goto mulAgain;
        
    }
    }
    
    
        if(value=='s'|| value=='S')
    {
        int subValue=subtraction();
        cout<<"subtraction  is "<<subValue<<endl;
        cout<<"Do you want to use our application again y or n"<<endl;
        subAgain:
        cin>>again;
        if(again=='y'||again=='Y')
        {
            goto start;
        }
        else if(again=='n'||again=='N'){
        cout<<"than you for use my application"<<endl;
        goto subAgain;
        
    }
    }
    
    
        if(value=='d'|| value=='D')
    {
        int divValue=division();
        cout<<"division  is "<<divValue<<endl;
        cout<<"Do you want to use our application again y or n"<<endl;
        divAgain:
        cin>>again;
        if(again=='y'||again=='Y')
        {
            goto start;
        }
        else if(again=='n'||again=='N'){
        cout<<"than you for use my application"<<endl;
        goto divAgain;
        
    }
    }
    
        if(value=='o'|| value=='O')
    {
        int moduleValue=modulo();
        cout<<"your modulo   is "<<moduleValue<<endl;
        cout<<"Do you want to use our application again y or n"<<endl;
        moduleAgain:
        cin>>again;
        if(again=='y'||again=='Y')
        {
            goto start;
        }
        else if(again=='n'||again=='N'){
        cout<<"than you for use my application"<<endl;
        goto moduleAgain;
        
    }
    }   
    else
    {
        cout<<"dear user you have invalid input plesse press again correct value"<<endl;
        goto start;
    }
    

}

//addition operations
int addition()
{
    int a;
    int total=0;
    char choice;
    add:
    cout<<"Enter a number"<<endl;
    cin>>a;
    total=total+a;
    cout<<"Do you want to add more numbers,y or n?"<<endl;
    addAgain:
    cin>>choice;
    if(choice=='y'||choice=='Y')
    {
        goto add;
    }
    else if(choice=='n'||choice=='N'){
        return total;
    }
    else {
        cout<<"dear user you have invalid input plesse press y ot n"<<endl;
        goto addAgain;
    }
    return total;
    }
 
 //multiplication operation
 
int multiplication()
{
    int a;
    int total=1;
    char choice;
    mul:
    cout<<"Enter a number"<<endl;
    cin>>a;
    total=total*a;
    cout<<"Do you want to multiply more numbers,y or n?"<<endl;
    mulAgain:
    cin>>choice;
    if(choice=='y'||choice=='Y')
    {
        goto mul;
    }
    else if(choice=='n'||choice=='N'){
        return total;
    }
    else
    {
        cout<<"dear user you have invalid input plesse press y ot n"<<endl;
        goto mulAgain;
    }
    return total;
    }
   
   
//subtraction

int subtraction()
{
    int a,b;
    int total=0;
    char choice;
    sub:
    cout<<"Enter two number"<<endl;
    cin>>a>>b;
   if(a>b){
   total=a-b;
   }
   else
   {
       total=b-a;
   }
    return total;
    }
    
    
    
//divisioin operation

  int division()
{
    int a,b;
    int total=0;
    char choice;
    divide:
    cout<<"Enter two number"<<endl;
    cin>>a>>b;
   if(a>b){
   total=a/b;
   }
   else
   {
       total=b/a;
   }
    return total;
    }
    
    
    //modulor operation
  int modulo()
{
    int a,b;
    int total=0;
    char choice;
    modulo:
    cout<<"Enter two number"<<endl;
    cin>>a>>b;
   if(a>b){
   total=a%b;
   }
   else
   {
       total=b%a;
   }
    return total;
    }
    

